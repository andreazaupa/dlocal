# -*- encoding : utf-8 -*-
module HomeHelper
end
